'''
Considere a classe para representar frações criada na aula. Melhore sua 
classe, adicionando nela o método simplifica, que deve reduzir o numera
dor e denominador até seus menores números. Atenção para o denominador, 
seu menor número é o 1. 
Invoque o método simplifica ao final de todas as operações que você criou, 
de modo que a fração resultante da operação já esteja simplificada. 
'''

class Fracao():
    def __init__(self, numerador, denominador):
        self.__numerador = numerador
        self.__denominador = denominador

    def __mul__(self, outro:'Fracao') -> 'Fracao':
        novo_numerador = (self.numerador * outro.numerador)
        novo_denominador = (self.denominador * outro.denominador)

        return Fracao(novo_numerador,novo_denominador)
    
    def __add__(self, outro:'Fracao') -> 'Fracao':
        
        if self.denominador == outro.denominador:
            novo_denominador = self.denominador
            novo_numerador = self.numerador + outro.numerador
        else:
            novo_denominador = self.denominador*outro.denominador
            novo_numerador = (novo_denominador*self.denominador/self.numerador) + (novo_denominador*outro.denominador/outro.numerador)

        return Fracao(novo_numerador, novo_denominador)
    
    def __sub__(self, outro:'Fracao') -> 'Fracao':
        if self.denominador == outro.denominador:
            novo_denominador = self.denominador
            novo_numerador = self.numerador - outro.numerador
        else:
            novo_denominador = self.denominador*outro.denominador
            novo_numerador = (novo_denominador*self.denominador/self.numerador) - (novo_denominador*outro.denominador/outro.numerador)

        return Fracao(novo_numerador, novo_denominador)
    
    def __truediv__(self, outro:'Fracao') -> 'Fracao':
        return Fracao(self.numerador*outro.denominador,self.denominador*outro.numerador)
    
    @property
    def numerador(self):
        return self.__numerador
    @property
    def denominador(self):
        return self.__denominador
    
    def __str__(self):
        return f'{self.__numerador}/{self.__denominador}'
    

f1 = Fracao(2,3)
print(f"\n A fração a ser operada é: {f1} ")

result1 = f1 + f1
result2 = f1 - f1
result3 = f1 * f1
result4 = f1 / f1

print(f"   - O resultado da soma é: {result1}")
print(f"   - O resultado da subtração é: {result2}")
print(f"   - O resultado da multiplicação é: {result3}")
print(f"   - O resultado da divisão é: {result4}\n")
