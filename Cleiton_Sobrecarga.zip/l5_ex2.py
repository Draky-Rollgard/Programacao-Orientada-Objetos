'''
Considere a definição de um ponto: P=(X,Y), onde X e Y são as coordenadas 
do ponto. Implemente uma classe para definir pontos manipular esses pon
tos. 
O construtor de Ponto deve aceitar os números reais X e Y. Este construtor 
também deve aceitar a criação de um ponto sem parâmetros e, neste caso, as 
coordenadas devem ser armazenadas com valor 0. Além do construtor, de
vem estar definidas as seguintes operações. 
Sejam dois pontos P1 = (X,Y) e P2 = (X2,Y2): 
a) Impressão do ponto P1 na tela: (X1, Y1) 
b) Adição P1+P2: retorna um novo objeto P3 = (X1 + X2, Y1 + Y2) 
c) Subtração P1–P2: retorna um novo objeto P3 = (X1 - X2, Y1 – Y2) 
d) Multiplicação P1*P2: retorna um valor numérico X1*X2 + Y1*Y2 
e) Multiplicação de um escalar por um ponto: n*P1: retorna um novo ob
jeto P3 = (n*X1, n*Y1). 
Atenção: Para essa operação o método a ser sobrecarregado é o 
__rmul__ 
'''
from random import randint

class Ponto:
    def __init__(self, X:float = 0, Y:float = 0):
        self.__X = X
        self.__Y = Y

    def __add__(self, outroPonto:'Ponto') -> 'Ponto':
        novo_x = self.X + outroPonto.X
        novo_y = self.Y + outroPonto.Y

        return Ponto(novo_x,novo_y)
    
    def __sub__(self, outroPonto:'Ponto') -> 'Ponto':
        novo_x = self.X - outroPonto.X
        novo_y = self.Y - outroPonto.Y

        return Ponto(novo_x,novo_y)
    
    def __mul__(self, outroPonto:'Ponto') -> float:
        novo_x = self.X * outroPonto.X
        novo_y = self.Y * outroPonto.Y
        resultado = novo_x+novo_y
        return resultado
    
    def __rmul__(self, k:float) -> 'Ponto':
        novo_x = k * self.X
        novo_y = k * self.Y

        return Ponto(novo_x,novo_y)

    @property    
    def X(self):
        return self.__X
    
    @property
    def Y(self):
        return self.__Y
    
    def __str__(self):
        return f'({self.X:.2f},{self.Y:.2f})'

#Pontos testes de instanciação
P1 = Ponto(2.3,5.2)
P2 = Ponto(1.2,3.3)
P3 = Ponto()
k = 3

#operações
soma = P1 + P2
subtracao = P1 - P2
multiplicacao = P1 * P2
multiplicacao_escalar = k * P1

print(f"\nOs pontos fornecidos são:\nP1{P1}\nP2{P2}\nP3{P3}")
print(f'\nsoma |P1 e P2|: P{randint(3,30)}{soma}') # vou gerando aleatórios para facilitar escolha de pontos *^-^*
print(f'subtração |P1 e P2|: P{randint(3,30)}{subtracao}')
print(f'multiplicação |P1 e P2|: {multiplicacao}')
print(f'multiplicação P1 com escalar {k}: P{randint(3,30)}{multiplicacao_escalar}')
multiplicacao = P1 * P3
print(f'multiplicação |P2 e P3|: {multiplicacao}\n')