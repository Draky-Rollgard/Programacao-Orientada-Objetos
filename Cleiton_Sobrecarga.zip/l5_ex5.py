'''
Exercício 5 
Crie uma classe Retangulo que represente um retângulo com largura e al
tura. Sobrecarregue os operadores de comparação para que seja possível 
comparar dois retângulos em relação a suas áreas: 
1. __lt__ (menor que): Verifique se a área do primeiro retângulo é menor 
que a do segundo. 
2. __gt__ (maior que): Verifique se a área do primeiro retângulo é maior 
que a do segundo. 
3. __eq__ (igual): Verifique se as áreas dos dois retângulos são iguais. 
Para testar: 
r1 = Retangulo(3, 4)  # Área = 12 
r2 = Retangulo(2, 6)  # Área = 12 
r3 = Retangulo(5, 2)  # Área = 10 
print(r1 == r2)  # Resultado esperado: True 
print(r1 > r3)   # Resultado esperado: True 
print(r3 < r2)   # Resultado esperado: True
'''

class Retangulo:
    def __init__(self, largura:float, altura:float):
        self.l = largura
        self.h = altura
    
    def __lt__(self, outro: 'Retangulo'):
        area1 = self.l * self.h
        area2 = outro.l * outro.h

        if area1 < area2:
            return True
        return False

    def __gt__(self, outro: 'Retangulo'):
        area1 = self.l * self.h
        area2 = outro.l * outro.h

        if area1 > area2:
            return True
        return False

    def __eq__(self, outro: 'Retangulo'):
        area1 = self.l * self.h
        area2 = outro.l * outro.h

        if area1 == area2:
            return True
        return False

r1 = Retangulo(3, 4)    # Área = 12 
r2 = Retangulo(2, 6)    # Área = 12 
r3 = Retangulo(5, 2)    # Área = 10 
print(r1 == r2) # Resultado esperado: True 
print(r1 > r3)  # Resultado esperado: True 
print(r3 < r2)  # Resultado esperado: True