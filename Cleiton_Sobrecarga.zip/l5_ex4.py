'''
Crie a classe SuperLista, que deve possuir um único atributo privado, do tipo 
list, que deve ser iniciado vazio no momento em que o objeto é construído, 
isto é, no seu construtor. 
Sobrecarregue o método __gt__, do operador > (maior que), para utilizar 
esse operador para adicionar elementos à sua lista. Sobrecarregue o método 
__str__ (ou __repr__), para imprimir os elementos já adicionados de 
acordo com o formato disponível no exemplo abaixo. Caso a lista esteja vazia, 
imprima a mensagem Lista vazia. 
Para testar: 
>>> lis = SuperLista() 
>>> print(lis) 
Lista vazia 
>>> lis > 10 
>>> lis > 'Adoro programar' 
>>> lis > 42 
>>> print(lis) 
[0] = 10 
[1] = Adoro programar 
[2] = 42
'''

class Superlista():
    def __init__(self) -> list:
        self.__lista = []

    def __gt__(self, novo_elemento):
        return self.__lista.append(novo_elemento)

    def __str__(self):
        if not self.__lista:
            return "Lista vazia"
        else:
            #for i, item in enumerate(self.__lista):
            #    return item
            resultado = ""
            for i, item in enumerate(self.__lista):
                resultado += f"[{i}] = {item}\n"
            return resultado
            

lis = Superlista()
print(lis)
lis > 10
lis > 'Adoro programar!'
lis > 42
print(lis)