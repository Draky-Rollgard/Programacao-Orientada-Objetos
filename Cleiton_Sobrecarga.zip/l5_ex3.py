'''
Desenvolva uma classe Relogio que represente um horário no formato 
HH:MM:SS. Com o auxílio de prints, imprima mensagens de aviso e evite que 
sejam atribuídos valores inválidos para hora, minuto e segundo. Sobrecarre
gue os métodos __repr__, __add__, __sub__, __eq__, __gt__ e __lt__, 
de forma que seu programa se comporte de acordo com as saídas a seguir: 

>>> r0 = Relogio(16,61,54) 
Horário digitado inválido 
>>> r1 = Relogio(18,37,32) 
>>> r2 = Relogio(20,0,30) 
>>> print(r1) 
18:37:32 
>>> print(r2) 
20:00:30 
>>> r3 = r1 + r2 
>>> print(r3) 
14:38:02 
>>> r4 = r3 – r2 
O primeiro horário deve ser maior que o segundo 
>>> print(r4) 
None 
>>> r4 = r2 – r3 
>>> print(r4) 
5:22:28 
>>> r1 == r2 
False 
>>> r1 == Relogio(18,37,32) 
True 
>>> r3 > r3 
False 
>>> r3 > r2 
False 
>>> r2 > r3 
True 
>>> r1 < r2 
True 
'''

class Relogio:
    def __init__(self, horas:int, minutos:int, segundos:int):
        if (horas <= 23 and horas >= 0) and (minutos <= 59 and minutos >= 0) and (segundos <= 59 and segundos >= 0):
            self.hh = horas
            self.mm = minutos
            self.ss = segundos
        else:
            print("Horário inválido! Por favor, faça uma nova tentativa com valores válidos.")

    def __repr__(self):
        return f"{self.hh:02}:{self.mm:02}:{self.ss:02}"

    def __add__(self, outro: 'Relogio') -> 'Relogio':
        novo_total_s = self.ss + outro.ss
        novo_total_m = self.mm + outro.mm
        novo_total_h = self.hh + outro.hh
        
        if novo_total_s > 59:
            m_temp = 0
            #m_temp =  novo_total_s // 60
            #novo_total_m = novo_total_m + m_temp
            while novo_total_s > 59:    
                novo_total_s = novo_total_s % 60#(novo_total_s / 60 - (novo_total_s // 60))*100 Estava usando a lógica errada
                m_temp=+1
            novo_total_m = novo_total_m + m_temp

        if novo_total_m > 59:
            h_temp = 0

            while novo_total_m > 59:    
                novo_total_m = novo_total_m % 60
                h_temp=+1
            novo_total_h = novo_total_h + h_temp

        if novo_total_h > 23:
            novo_total_h = novo_total_h - 24

        return Relogio(novo_total_h,novo_total_m,novo_total_s)
   
    def __sub__(self, outro: 'Relogio') -> 'Relogio':
        if self.hh < outro.hh or (self.hh == outro.hh and self.mm < outro.mm) or (self.hh == outro.hh and self.mm == outro.mm and self.ss < outro.ss):
            print("O primeiro horário deve ser maior que o segundo")
            return None
        
        novo_total_s = self.ss - outro.ss
        #novo_total_m = self.mm - outro.mm
        #novo_total_h = self.hh - outro.hh
        #novo_total_s = self.ss - outro.ss
        
        if novo_total_s < 0:
            novo_total_s += 60
            self.mm -= 1

        novo_total_m = self.mm - outro.mm
        if novo_total_m < 0:
            novo_total_m += 60
            self.hh -= 1

        novo_total_h = self.hh - outro.hh
        if novo_total_h < 0:
            novo_total_h += 24

        return Relogio(novo_total_h, novo_total_m, novo_total_s)
        

    def __eq__(self, outro:'Relogio'):
        if self.ss == outro.ss and self.mm == outro.mm and self.ss == outro.ss:
            print(True)
        else:
            print(False)

    #se o primeiro > segundo deve ser greater than
    def __gt__(self,outro: 'Relogio'):
        if self.ss == outro.ss and self.mm == outro.mm and self.ss == outro.ss:
            print(False)
        
        if self.hh != outro.hh:
            if self.hh > outro.hh:
                print(True)
            else:
                print(False)
        else:
            if self.mm != outro.mm:
                if self.mm > outro.mm:
                    print(True)
                else:
                    print(False)
            else:
                if self.ss != outro.ss:
                    if self.ss < outro.ss:
                        print(False)
                    else:
                        print(True)

    #se o primeiro < segundo - less than
    def __lt__(self,outro: 'Relogio'):
        if self.ss == outro.ss and self.mm == outro.mm and self.ss == outro.ss:
            print(False)
        
        if self.hh != outro.hh:
            if self.hh < outro.hh:
                print(True)
            else:
                print(False)
        else:
            if self.mm != outro.mm:
                if self.mm < outro.mm:
                    print(True)
                else:
                    print(False)
            else:
                if self.ss != outro.ss:
                    if self.ss > outro.ss:
                        print(False)
                    else:
                        print(True)        
        '''
        MÉTODO INVIÁVEL
        if self.hh <= outro.hh:
            print(True)
        elif self.mm <= outro.mm: 
            if self.ss < outro.ss:
                print(True)

        else:         
            print(False)
        '''
#r1 = Relogio(23,59,59)
#r2 = Relogio(00,00,59)
'''
TESTES INICIAIS
r1 = Relogio(18,37,32)
r2 = Relogio(20,00,30)
r3 = Relogio(18,37,32)

soma = r1 + r2

print(r1)
print(r2)
print(r3)

print(soma)
r1==r2
r1==r3
'''

r0 = Relogio(16,61,54)
r1 = Relogio(18,37,32) 
r2 = Relogio(20,0,30)
print(r1) 
print(r2) 
r3 = r1 + r2 
print(r3) 
r4 = r3 - r2  
print(r4)  
r4 = r2 - r3 
print(r4) 
r1 == r2 
r1 == Relogio(18,37,32) 
#print("\n")
r3 > r3 
r3 > r2 
r2 > r3 
r1 < r2 


'''
ESPERADO DO TERMINAL
Horário digitado inválido 
18:37:32 
20:00:30  
14:38:02  
O primeiro horário deve ser maior que o segundo 
None 
5:22:28 
False 
True
False 
False 
True 
True 
'''