'''
Crie uma classe chamada FormaGeometrica, que possui os atributos area 
e perimetro. 
Implemente as subclasses Retangulo e Triangulo, que devem conter os 
métodos calcula_area() e calcula_perimetro(), herdados da super
classe. A classe Retangulo deve ter os atributos base e altura. A classe 
Triangulo deve ter os atributos lado1, lado2 e lado3. 
No código de teste, crie um objeto da classe Triangulo e outro da classe 
Retangulo. Verifique se os dois são mesmo instâncias da mesma classe 
FormaGeometrica (use isinstance), e calcule a área de cada um. 
'''
import math # para calcular area triangulo q nao tem base

class FormaGeometrica:
    def __init__(self, area: float = 0.0, perimetro: float = 0.0):
        self.area = area
        self.perimetro = perimetro

class Retangulo(FormaGeometrica):
    def __init__(self, base: float, altura: float):
        super().__init__()
        self.base = base 
        self.altura = altura

    def calcula_area(self) -> float: 
        self.area = self.base * self.altura
        return self.area
        
    def calcula_perimetro(self)-> float:
        self.perimetro = (self.base * 2) + (self.altura * 2)
        return self.perimetro
    
class Triangulo(FormaGeometrica):
    def __init__(self, lado1: float, lado2: float, lado3: float):
        super().__init__()
        self.lado1 = lado1
        self.lado2 = lado2
        self.lado3 = lado3
    
    def calcula_area(self):
        # Como não sei a base, calcular pelo metodo de herão, onde p = (a+b+c)/2 e A = raiz(p (p-a) (p-b) (p-c))
        p = (self.lado1 + self.lado2 + self.lado3) * 0.5
        self.area = math.sqrt(p * (p - self.lado1) * (p - self.lado2) * (p - self.lado3))
        return round(self.area)
    
    def calcula_perimetro(self):
        self.perimetro = self.lado1 + self.lado2 + self.lado3
        return self.perimetro

retangulo = Retangulo(5, 5)
print(f"Retângulo: Área = {Retangulo.calcula_area(retangulo)}  Perímetro = {retangulo.calcula_perimetro()}")
TrianguloQualquer = Triangulo(2, 3.4, 2)
print(f"Triângulo: Área = {TrianguloQualquer.calcula_area()}  Perímetro = {TrianguloQualquer.calcula_perimetro()}")
