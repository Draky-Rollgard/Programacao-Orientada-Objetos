'''
Criar uma hierarquia de classes em Python para representar uma conta 
bancária, uma conta corrente e uma conta poupança. Utilize conceitos de 
herança para evitar duplicação de código. Utilize encapsulamento para pro
teger os atributos das classes. Por fim, adicione validações necessárias, 
como verificar se o valor do saque não é negativo. 
ContaBancaria 
Atributos: 
• nome: Nome do titular da conta (string). 
• saldo: Saldo da conta (float). 
Métodos: 
• depositar(valor): Adiciona o valor ao saldo. 
• sacar(valor): Subtrai o valor do saldo, se houver saldo suficiente. 
• exibir_saldo(): Exibe o saldo atual da conta. 
ContaCorrente (herda de ContaBancaria) 
Atributos: 
• limite_cheque_especial: Valor do limite do cheque especial (float). 
Métodos: 
• sacar(valor): Sobrescrever o método para permitir saque além do 
saldo até o limite do cheque especial. 
• exibir_saldo(): Exibir o saldo atual considerando o cheque especial. 
Classe Derivada: ContaPoupanca (herda de ContaBancaria) 
Atributos: 
• taxa_juros: Taxa de juros anual (float). 
Métodos: 
• aplicar_juros(): Aplicar juros ao saldo com base na taxa de juros 
anual. 
'''
class ContaBancaria:
    def __init__(self, nome: str, saldo: float):
        self.__nome = nome
        self.__saldo = saldo
    
    
    def depositar(self, valor):
        if valor >0:
            self.__saldo = self.__saldo + valor
            print(f"Valor de R${valor} foi depositado. Saldo atual de R${self.__saldo}.")
        else:
            print("Valor do depósito não deve ser nulo e, também, negativo. Favor, tente novamente")

    def sacar(self, valor):
        if self.__saldo >= valor:
            self.__saldo = self.__saldo - valor
            print(f"Saque de R${valor} realizado. Seu saldo atual é de R${self.__saldo}.")
        else:
            print(f"Você está sem saldo. Valor disponível para saque: R${self.__saldo}")
    
    def exibir_saldo(self):
        return self.__saldo

class ContaCorrente(ContaBancaria):
    def __init__(self, nome, saldo, limite_cheque_especial: float):
        super().__init__(nome, saldo)
        self.__limite_cheque_especial = limite_cheque_especial

    
    def sacar(self, valor):
        
        if valor <= 0:
            print("Valor inválido para saque")

        novo_total = (self._ContaBancaria__saldo + self.__limite_cheque_especial)
        if valor > (novo_total):
            print(f"Excedido o limite para saque. Valor disponível:{(novo_total)}")
        else:
            self._ContaBancaria__saldo = self._ContaBancaria__saldo - valor
            print (f"Saque no valor de {valor} realizado com sucesso. Novo saldo: R${self._ContaBancaria__saldo}")
    
    def exibir_saldo(self):
        saldo_cheque = (self._ContaBancaria__saldo + self.__limite_cheque_especial)
        print(f"Saldo atual da Conta Corrente de R${saldo_cheque} com cheque especial")

class ContaPoupanca(ContaBancaria):
    def __init__(self, nome, saldo, taxa_juros: float):
        super().__init__(nome, saldo)
        self.__taxa_juros = taxa_juros

    def aplicar_juros(self):
        juros = self._ContaBancaria__saldo * (self.__taxa_juros / 100)
        self._ContaBancaria__saldo += juros
        print(f"Juros de R${juros:.2f} aplicados com sucesso. Novo saldo: R${self._ContaBancaria__saldo:.2f}")

print("\nConta do João")
conta_bancaria = ContaBancaria("João", 500)
conta_bancaria.exibir_saldo()
conta_bancaria.depositar(100)
conta_bancaria.sacar(200)
conta_bancaria.exibir_saldo()

print("\nConta da Maria")
conta_corrente = ContaCorrente("Maria", 1000, 500)
conta_corrente.exibir_saldo()
conta_corrente.depositar(200)
conta_corrente.sacar(1200)
conta_corrente.exibir_saldo()

print("\nConta do Pedro")
conta_corrente = ContaCorrente("Pedro", 1000, 12000)
conta_corrente.exibir_saldo()
conta_corrente.depositar(3000)
conta_corrente.sacar(1200)
conta_corrente.exibir_saldo()

print("\nConta do Carlos")
conta_poupanca = ContaPoupanca("Carlos", 1500, 5)
conta_poupanca.exibir_saldo()
conta_poupanca.aplicar_juros()
conta_poupanca.exibir_saldo()
print("\n")