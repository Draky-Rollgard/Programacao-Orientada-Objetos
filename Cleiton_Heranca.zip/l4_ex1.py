'''
Crie duas classes: Funcionário e Gerente. 
• A classe Gerente deve herdar de Funcionário 
• Os atributos de Funcionário são: nome, CPF, salário e departamento 
• A classe Funcionário tem o método bonificar(), que não recebe 
nenhum parâmetro, e acrescenta 10% ao salário dele 
• A classe Gerente deve ter atributos adicionais de senha e número de 
funcionários gerenciados 
o A classe Gerente tem dois métodos a mais 
o O método autenticar_senha(senha), que apenas compara a 
senha do parâmetro com o valor do atributo senha, retornando 
True ou False. 
o O método bonificar(), que acrescenta ao gerente o valor de 
15% ao seu salário. 
• Crie objetos e teste suas classes.
'''
class Funcionario:
    def __init__(self, nome: str, CPF: str, salario: float, departamento: str):
        self.nome = nome
        self.CPF = CPF
        self.salario = salario
        self.departamento = departamento

    def bonificar(self):
        return round((self.salario * 1.1), 2)

class Gerente(Funcionario):
    def __init__(self, nome, CPF, salario, departamento, senha: str, num_func_gerenciados: int):
        super().__init__(nome, CPF, salario, departamento)
        self.senha = senha
        self.num_func_gerenciados = num_func_gerenciados
    
    def autenticar_senha(self, senha):
        return self.senha == senha

    def bonificar(self):
        novo = self.salario * 1.15
        return round (novo, 2)
    

funcionario1 = Funcionario("Fulano", "000.999.000-99", 1200.00, "Projetos")
print ("Funcionário 1 bonificação salarial:",Funcionario.bonificar(funcionario1))
gerente1 = Gerente("Ciclano", "920.920.333-29", 6650.00, "Projetos", "senha123", 2)
print ("Bonificação salarial do Gerente atual é: ", Gerente.bonificar(gerente1))
senha_qualquer = "Roger$$237@Jcast"
print(f"A senha {senha_qualquer} apresenta o status ({Gerente.autenticar_senha(gerente1, senha_qualquer)}) da senha cadastrada.")