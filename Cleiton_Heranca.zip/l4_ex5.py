'''
Crie um sistema para gerenciar pagamentos: 
1. Classe Base: Pagamento 
o Atributos: valor, data. 
o Método: processar_pagamento() que imprime "Processando 
pagamento genérico". 
2. Classes Derivadas: 
o PagamentoCartao: Adicione atributos adicionais 
numero_cartao, validade e sobrescreva o método 
processar_pagamento() para exibir "Pagamento realizado via 
cartão". 
o PagamentoPix: Adicione um atributo adicional chave_pix e so
brescreva o método processar_pagamento() para exibir "Paga
mento realizado via PIX". 
Crie objetos das duas classes derivadas, processe pagamentos e mostre de
talhes de cada transação.
''' 
from datetime import date
class Pagamento:
    def __init__(self, valor: float, data: date) -> None:
        self.valor = valor
        self.data = data
    
    def processar_pagamento(self) -> None:
        print("Processando pagamento genérico")
    
class PagamentoCartao(Pagamento):
    def __init__(self, valor: float, data: date, numero_cartao: str, validade: str):
        super().__init__(valor, data)
        self.numero_cartao = numero_cartao
        self.validade = validade
    
    def processar_pagamento(self):
        if self.valor > 0:
            print("Pagamento realizado via cartão")
        else:
            print("Valor inválido para pagamento")

class PagamentoPix(Pagamento):
    def __init__(self, valor: float, data: date, chave_pix:str):
        super().__init__(valor, data)
        self.chave_pix = chave_pix

    def processar_pagamento(self):
        if self.valor > 0:
            print("Pagamento realizado via PIX")


print("\nTeste 1: Pagamento genérico")
pagamento1 = Pagamento(100.0, date(2024, 12, 10))
pagamento1.processar_pagamento()

print("\nTeste 2: Pagamento com Cartão")
pagamento2 = PagamentoCartao(150.0, date(2024, 12, 10), '1234 5678 9012 3456', '12/26')
pagamento2.processar_pagamento() 

print("\nTeste 3: Pagamento via PIX")
pagamento3 = PagamentoPix(50.0, date(2024, 12, 10), 'chave@pix.com')
pagamento3.processar_pagamento()

print("\nTeste 4: Pagamento com valor negativo")
pagamento4 = PagamentoCartao(-100.0, date(2024, 12, 10), '1234 5678 9012 3456', '12/26')
pagamento4.processar_pagamento()

print("\nTeste 5: Múltiplos pagamentos")
pagamento5 = PagamentoCartao(120.0, date(2024, 12, 10), '9876 5432 1098 7654', '11/25')
pagamento6 = PagamentoPix(200.0, date(2024, 12, 29), 'outro@pix.com')
pagamento5.processar_pagamento() 
pagamento6.processar_pagamento()  

print("\nTeste 6: Formato diferente de data e chave")
pagamento7 = PagamentoCartao(75.0, date(2024, 12, 17), '4444 5555 6666 7777', '03/27')
pagamento8 = PagamentoPix(300.0, date(2024, 12, 15), 'meuemail@pix.com')  
pagamento7.processar_pagamento()
pagamento8.processar_pagamento()