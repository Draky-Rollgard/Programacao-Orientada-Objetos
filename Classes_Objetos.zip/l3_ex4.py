'''
Implemente uma classe Retangulo para representar um retângulo no plano 
cartesiano. 
a) O retângulo deve ser representado pelos atributos largura, altura 
e um ponto (canto inferior esquerdo), que será uma instância da 
classe Ponto2D criada anteriormente. 
b) O construtor deve permitir inicializar a largura, a altura e o ponto 
de origem, validando que largura e altura sejam valores positivos.  
c) Forneça métodos de acesso (getter/setter) para largura e altura. 
d) Implemente um método mover, que desloca o retângulo para um 
novo ponto passado como parâmetro.  
e) Crie um método que calcule a área do retângulo. 
f) Implemente um método intersecao que verifica se dois retângulos 
se sobrepõem, retornando True ou False. 
g) Escreva código de teste que instancie objetos de exemplo e demonstre 
as funcionalidades da classe.
'''

class Ponto2D:
    def __init__(self, x=0.0, y=0.0):
        self.x = x
        self.y = y

    def get_x(self):
        return self.x

    def set_x(self, x):
        self.x = x

    def get_y(self):
        return self.y

    def set_y(self, y):
        self.y = y

    def compara(self, outro_ponto):
        return self.x == outro_ponto.get_x() and self.y == outro_ponto.get_y()

    def __str__(self):
        return f"Ponto2D({self.x}, {self.y})"

    def distancia(self, outro_ponto):
        dx = self.x - outro_ponto.get_x()
        dy = self.y - outro_ponto.get_y()
        return (dx ** 2 + dy ** 2) ** 0.5 # divisão por 2

    def clone(self):
        return Ponto2D(self.x, self.y)


class Retangulo:
    def __init__(self, largura, altura, ponto_inferior_esquerdo: Ponto2D):
        if largura <= 0 or altura <= 0:
            raise ValueError("Somente positivo.")
        self.largura = largura
        self.altura = altura
        self.ponto_inferior_esquerdo = ponto_inferior_esquerdo

    def get_largura(self):
        return self.largura

    def set_largura(self, largura):
        if largura <= 0:
            raise ValueError("Somente positivo.")
        self.largura = largura

    def get_altura(self):
        return self.altura

    def set_altura(self, altura):
        if altura <= 0:
            raise ValueError("Somente positivo.")
        self.altura = altura

    def mover(self, novo_ponto: Ponto2D):
        self.ponto_inferior_esquerdo = novo_ponto

    def area(self):
        return self.largura * self.altura

    def intersecao(self, outro_retangulo):
        x1, y1 = self.ponto_inferior_esquerdo.get_x(), self.ponto_inferior_esquerdo.get_y()
        x2, y2 = x1 + self.largura, y1 + self.altura
        x1_outro, y1_outro = outro_retangulo.ponto_inferior_esquerdo.get_x(), outro_retangulo.ponto_inferior_esquerdo.get_y()
        x2_outro, y2_outro = x1_outro + outro_retangulo.largura, y1_outro + outro_retangulo.altura

        if x1 < x2_outro and x2 > x1_outro and y1 < y2_outro and y2 > y1_outro:
            return True
        return False

    def __str__(self):
        return f"Retângulo(L = {self.largura}, H = {self.altura}, Inferior esquerdo = {self.ponto_inferior_esquerdo})"


ponto1 = Ponto2D(1.0, 1.0)
ponto2 = Ponto2D(4.0, 4.0)

retangulo1 = Retangulo(3.0, 2.0, ponto1)
retangulo2 = Retangulo(2.0, 2.0, ponto2)
retangulo3 = Retangulo(1.0, 1.0, Ponto2D(5.0, 5.0))

print(f"Largura R1: {retangulo1.get_largura()}")
print(f"Altura R1: {retangulo1.get_altura()}")
print(f"Área R1: {retangulo1.area()}\n")

print(f"Largura R2: {retangulo2.get_largura()}")
print(f"Altura R2: {retangulo2.get_altura()}")
print(f"Área R2: {retangulo2.area()}\n")

print(f"Largura R3: {retangulo3.get_largura()}")
print(f"Altura R3: {retangulo3.get_altura()}")
print(f"Área R3: {retangulo3.area()}\n")

retangulo1.mover(Ponto2D(3.0, 5.0))
print(f"R1 após se mover: {retangulo1}")
print(f"R1 e R2 se sobrepõem? {retangulo1.intersecao(retangulo2)}")
print(f"R1 e R3 se sobrepõem? {retangulo1.intersecao(retangulo3)}\n")

retangulo1.mover(Ponto2D(2.0, 0.0))
print(f"R1 após se mover: {retangulo1}")
print(f"R1 e R2 se sobrepõem? {retangulo1.intersecao(retangulo2)}")
print(f"R1 e R3 se sobrepõem? {retangulo1.intersecao(retangulo3)}")


