'''
Crie uma classe ContaCorrente que represente uma conta bancária sim
ples. 
a) A conta bancária deve ser representada pelos atributos: número da 
conta, titular, saldo e limite de saque. 
b) O construtor deve inicializar todos os atributos, garantindo que o 
saldo e o limite de saque sejam não negativos.  
c) Forneça métodos de acesso (getter/setter) para cada atributo 
d) Implemente um método depositar que recebe um valor e adiciona 
ao saldo, desde que o valor seja positivo. 
e) Implemente um método sacar que reduz o saldo em um valor espe
cificado, se houver saldo suficiente e o valor estiver dentro do limite 
de saque. 
f) Implemente um método transferir que recebe outra instância de Con
taCorrente e um valor, e transfere o valor entre as contas se hou
ver saldo suficiente. 
g) Escreva código de teste que instancie objetos de exemplo e demonstre 
as capacidades da classe.
'''

class ContaCorrente:
    def __init__(self, numero_conta, titular, saldo=0.0, limite_saque=1000.0):
        self.numero_conta = numero_conta
        self.titular = titular
        self.saldo = saldo if saldo >= 0 else 0.0
        self.limite_saque = limite_saque if limite_saque >= 0 else 0.0

    def get_numero_conta(self):
        return self.numero_conta

    def set_numero_conta(self, numero_conta):
        self.numero_conta = numero_conta

    def get_titular(self):
        return self.titular

    def set_titular(self, titular):
        self.titular = titular

    def get_saldo(self):
        return self.saldo

    def set_saldo(self, saldo):
        if saldo >= 0:
            self.saldo = saldo

    def get_limite_saque(self):
        return self.limite_saque

    def set_limite_saque(self, limite_saque):
        if limite_saque >= 0:
            self.limite_saque = limite_saque

    def depositar(self, valor):
        if valor > 0:
            self.saldo += valor
            print(f"Realizado depósito de R${valor:.2f}")
        else:
            print("Valor de depósito inválido.")

    def sacar(self, valor):
        if valor > 0 and valor <= self.saldo and valor <= self.limite_saque:
            self.saldo -= valor
            print(f"Saque de R${valor:.2f} realizado com sucesso!")
        elif valor > self.saldo:
            print("Saldo insuficiente para o saque.")
        elif valor > self.limite_saque:
            print(f"Excedido o limite de saque de R${self.limite_saque:.2f}.")
        else:
            print("Valor de saque naõ deve ser negativo.")

    def transferir(self, outra_conta, valor):
        if valor > 0 and valor <= self.saldo:
            self.sacar(valor)
            outra_conta.depositar(valor)
            print(f"Transferência de R${valor:.2f} realizada para a conta {outra_conta.get_numero_conta()}.")
        else:
            print("Saldo insuficiente.")

    def __str__(self):
        return f"Conta Corrente {self.numero_conta} - Titular: {self.titular}, Saldo: R${self.saldo:.2f}, Limite de Saque: R${self.limite_saque:.2f}"


conta1 = ContaCorrente(12345, "João Silva", saldo=1000.0, limite_saque=500.0)
conta2 = ContaCorrente(67890, "Maria Oliveira", saldo=1500.0, limite_saque=1000.0)
print(conta1)
print(conta2)

conta1.depositar(500.0)
conta2.depositar(-200.0)
print(conta1)
print(conta2)

conta1.sacar(200.0)
conta1.sacar(600.0)
conta2.sacar(1000.0)
print(conta1)
print(conta2)

conta1.transferir(conta2, 300.0)
conta1.transferir(conta2, 1500.0)
print(conta1)
print(conta2)
