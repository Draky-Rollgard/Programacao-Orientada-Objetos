'''
Escreva uma classe que represente um país. Um país é representado através 
dos atributos: código ISO 3166-1 (ex.: BRA), nome (ex.: Brasil), população (ex.: 
193.946.886) e a sua dimensão em Km2 (ex.: 8.515.767,049). Além disso, cada 
país mantém uma lista de outros países com os quais ele faz fronteira. Es
creva a classe em Python e forneça os seus membros a seguir: 
a) Construtor que inicialize o código ISO, o nome e a dimensão do país;  
b) Métodos de acesso (getter/setter) para as propriedades código ISO, 
nome, população e dimensão do país; 
c) Um método que permita verificar se dois objetos representam o 
mesmo país (igualdade semântica). Dois países são iguais se tiverem 
o mesmo código ISO; 
d) Um método que informe se outro país é limítrofe do país que recebeu 
a mensagem; 
e) Um método que retorna a densidade populacional do país; 
f) Um método que receba um país como parâmetro e retorne a lista de 
vizinhos comuns aos dois países. 
g) Escreva código de teste que instancie objetos de exemplo e demonstre 
as capacidades da classe.
'''
class Pais:
    def __init__(self, codigo_iso, nome, populacao, dimensao_km2):
        self.codigo_iso = codigo_iso
        self.nome = nome
        self.populacao = populacao
        self.dimensao_km2 = dimensao_km2
        self.fronteiras = []

    def get_codigo_iso(self):
        return self.codigo_iso

    def set_codigo_iso(self, codigo_iso):
        self.codigo_iso = codigo_iso

    def get_nome(self):
        return self.nome

    def set_nome(self, nome):
        self.nome = nome

    def get_populacao(self):
        return self.populacao

    def set_populacao(self, populacao):
        self.populacao = populacao

    def get_dimensao_km2(self):
        return self.dimensao_km2

    def set_dimensao_km2(self, dimensao_km2):
        self.dimensao_km2 = dimensao_km2

    def igual(self, outro_pais):
        return self.codigo_iso == outro_pais.get_codigo_iso()

    def e_limite(self, outro_pais):
        return outro_pais in self.fronteiras

    def adicionar_fronteira(self, pais):
        if pais not in self.fronteiras:
            self.fronteiras.append(pais)

    def densidade_populacional(self):
        return self.populacao / self.dimensao_km2 if self.dimensao_km2 > 0 else 0

    def vizinhos_comuns(self, outro_pais):
        return list(set(self.fronteiras).intersection(set(outro_pais.fronteiras)))

        #return list(set(self.fronteiras) and set(outro_pais.fronteiras))
    
    def __str__(self):
        return f"{self.nome} ({self.codigo_iso}), População: {self.populacao}, Dimensão: {self.dimensao_km2} km²"

#INSERE PAIS
pais1 = Pais("BRA", "Brasil", 193946886, 8515767.049)
pais2 = Pais("ARG", "Argentina", 45195777, 2780400)
pais3 = Pais("COL", "Colômbia", 50882891, 1141748)
pais4 = Pais("CHL", "Chile", 19116209, 756102)
pais5 = Pais("PER", "Peru", 32971854, 1285216)#
pais6 = Pais("BOL", "Bolívia", 11673021, 1098581)
pais7 = Pais("MEX", "México", 126190788, 1964375)#
pais8 = Pais("RUS", "Rússia", 145912025, 17098242)
pais9 = Pais("CAN", "Canadá", 37742154, 9984670)#
pais10 = Pais("USA", "Estados Unidos", 331002651, 9833517)

#INSERE FRONTEIRA
pais1.adicionar_fronteira(pais2)
pais1.adicionar_fronteira(pais3)
pais2.adicionar_fronteira(pais1)
pais3.adicionar_fronteira(pais1)
pais3.adicionar_fronteira(pais4)
pais4.adicionar_fronteira(pais3)

pais1.adicionar_fronteira(pais5)
pais5.adicionar_fronteira(pais1)
pais1.adicionar_fronteira(pais6)
pais6.adicionar_fronteira(pais1)
pais2.adicionar_fronteira(pais5)
pais5.adicionar_fronteira(pais2)
pais9.adicionar_fronteira(pais10)  
pais10.adicionar_fronteira(pais9)

#PRINTA PAIS
print(f"\nPaís 1: {pais1}")
print(f"País 2: {pais2}")
print(f"País 3: {pais3}")
print(f"País 4: {pais4}")
print(f"País 5: {pais5}")
print(f"País 6: {pais6}")
print(f"País 7: {pais7}")
print(f"País 8: {pais8}")
print(f"País 9: {pais9}")
print(f"País 10: {pais10}\n")

#QUESTÃO C à F
print(f"Brasil e Argentina são iguais? {pais1.igual(pais2)}")
print(f"Brasil e Brasil são iguais? {pais1.igual(pais1)}\n")
print(f"Brasil e Argentina têm fronteira? {pais1.e_limite(pais2)}")
print(f"Brasil e Chile têm fronteira? {pais1.e_limite(pais4)}")
print(f"Brasil e Peru têm fronteira? {pais1.e_limite(pais5)}")
print(f"Argentina e Peru têm fronteira? {pais2.e_limite(pais5)}")
print(f"Canadá e Estados Unidos têm fronteira? {pais9.e_limite(pais10)}\n")

print(f"Densidade populacional do Brasil: {pais1.densidade_populacional():.2f} habitantes/km²")
print(f"Densidade populacional da Colômbia: {pais3.densidade_populacional():.2f} habitantes/km²")
print(f"Densidade populacional do México: {pais7.densidade_populacional():.2f} habitantes/km²")
print(f"Densidade populacional da Rússia: {pais8.densidade_populacional():.2f} habitantes/km²\n")

vizinhos_comuns = pais3.vizinhos_comuns(pais1)
print(f"Vizinhos comuns entre Colômbia e Chile: {[p.nome for p in pais3.vizinhos_comuns(pais4)]}")
print(f"Vizinhos comuns entre Brasil e Peru: {[p.nome for p in pais1.vizinhos_comuns(pais5)]}")
print(f"Vizinhos comuns entre Brasil e Chile: {[p.nome for p in pais1.vizinhos_comuns(pais4)]}")







