'''
Crie uma classe para representar datas. 
a) Represente uma data usando três atributos: o dia, o mês, e o ano. 
b) Sua classe deve ter um construtor que inicializa os três atributos e ve
rifica a validade dos valores fornecidos. 
c) Forneça um método set um get para cada atributo. 
d) Forneça o método __str__ para retornar uma representação da data 
como string. Considere que a data deve ser formatada mostrando o 
dia, o mês e o ano separados por barra (/). 
e) Forneça uma operação para avançar a data para o dia seguinte. 
f) Escreva código de teste que instancie objetos de exemplo e demonstre 
as capacidades da classe. 
Garanta que uma instância desta classe sempre esteja em um estado consis
tente.
'''

class Data:
    def __init__(self, dia: int, mes: int, ano: int):
        '''self.set_ano(ano)
        self.set_mes(mes)
        self.set_dia(dia)'''

        # Validaçao para evitar criação de objeto
        if not self.set_ano(ano):
            return
        else:
            self.set_ano(ano)

        if not self.set_mes(mes):
            return 
        else:
            self.set_mes(mes)
        if not self.set_dia(dia):
            return
        else:
            self.set_dia(dia)


    def numerodiasdomes(self, mes, ano):    
        if mes in {1, 3, 5, 7, 8, 10, 12}:  
            return 31
        elif mes in {4, 6, 9, 11}:  
            return 30
        elif mes == 2:
            if (ano % 4 == 0 and ano % 100 != 0) or (ano % 400 == 0):  
                return 29  # Ano bissexto
            else:
                return 28
        return 0

    def set_dia(self, dia):
        if dia < 1 or dia > self.numerodiasdomes(self.mes, self.ano):   
            print(f"Erro: Dia {dia} é inválido para o mês {self.mes} no ano {self.ano}.")
            return False
        else:
            self.dia = dia
            return True

    def get_dia(self):
        return self.dia

    def set_mes(self, mes):
        if mes < 1 or mes > 12:
            print(f"Erro: Mês {mes} é inválido.")
            return False
        else:
            self.mes = mes
            return True

    def get_mes(self):
        return self.mes

    def set_ano(self, ano):
        if ano < 1:
            print(f"Erro: Ano {ano} inválido.")
            return False
        else:
            self.ano = ano
            return True

    def get_ano(self):
        return self.ano

    def __str__(self):
        return f"{self.dia:02d}/{self.mes:02d}/{self.ano}"

    def avancar_dia(self):
        if not hasattr(self, 'dia') or not hasattr(self, 'mes') or not hasattr(self, 'ano'):
            print("Erro: Não é possível avançar a data, pois não é válida.")
            return
        
        if self.dia <= 0 or self.mes <= 0 or self.mes > 12 or self.dia > self.numerodiasdomes(self.mes, self.ano):
            print("Erro: Não é possível avançar a data, pois a data é inválida.")
            return
        
        self.dia += 1
        if self.dia > self.numerodiasdomes(self.mes, self.ano):
            self.dia = 1
            self.mes += 1
            if self.mes > 12:
                self.mes = 1
                self.ano += 1


# Testes
data1 = Data(29, 2, 2024)  # Ano bissexto, é valido
print("Data inicial:", data1)

data1.avancar_dia()
print("Após avançar um dia:", data1)

data1.set_dia(21)
data1.set_mes(12)
data1.set_ano(2024)
print("Data modificada:", data1)

# Testando datas inválidas
data2 = Data(30, 2, 2024) #não tem 30 dias
data2.avancar_dia()

#Verificamdo impressao
#print(str(data2))
#print(data2)

data3 = Data(-1, 4, 2024) #não tem 31 dias
data3.avancar_dia()

data4 = Data(28, 14, 2024) # não exitem 14 meses
data4.avancar_dia() 

data5 = Data(21, 12, -1000) # sem ano negativo, meu código não recebe antes de cristo
data5.avancar_dia()

data6 = Data(200, -13, 0) #teste de erro em todos os campos com ano 0 inexistente
data6.avancar_dia()

data7 = Data(1.2, 10, 2.2) #teste de float
data7.avancar_dia()
