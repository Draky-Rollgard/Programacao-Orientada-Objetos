'''
Escreva em Python uma classe Circulo, que representa um círculo no plano 
cartesiano. Forneça os seguintes membros de classe: 
a) Um construtor que receba o raio e um ponto (o centro do círculo), 
sendo que o parâmetro ponto deve ser do tipo Ponto2D, criado ante
riormente. 
b) Métodos de acesso ao atributo raio do círculo 
c) Métodos inflar e desinflar, que, respectivamente, aumentam e 
diminuem o raio do círculo de um dado valor 
d) Método mover, que recebe um ponto por parâmetro, que: 
• caso o ponto não seja passado, leva o círculo para a origem do 
espaço 2D, isto é, ponto (0, 0) 
• caso o ponto seja passado, move o círculo para o ponto indi
cado pelo parâmetro 
e) Método que retorna a área do círculo 
Escreva código de teste que instancie objetos de exemplo e demonstre as 
capacidades da classe.
'''
import math

class Ponto2D:
    def __init__(self, x=0.0, y=0.0):
        self.x = x
        self.y = y

    def get_x(self):
        return self.x

    def set_x(self, x):
        self.x = x

    def get_y(self):
        return self.y

    def set_y(self, y):
        self.y = y

    def compara(self, outro_ponto):
        return self.x == outro_ponto.get_x() and self.y == outro_ponto.get_y()

    def __str__(self):
        return f"Ponto2D({self.x}, {self.y})"

    def distancia(self, outro_ponto):
        dx = self.x - outro_ponto.get_x()
        dy = self.y - outro_ponto.get_y()
        return math.sqrt(dx ** 2 + dy ** 2)

    def clone(self):
        return Ponto2D(self.x, self.y)

class Circulo:
    def __init__(self, raio, centro: Ponto2D):
        self.raio = raio
        self.centro = centro

    def get_raio(self):
        return self.raio

    def set_raio(self, raio):
        self.raio = raio

    def inflar(self, valor):
        self.raio += valor

    def desinflar(self, valor):
        self.raio -= valor

    def mover(self, ponto=None):
        if ponto is None:
            self.centro = Ponto2D(0, 0)
        else:
            self.centro = ponto

    def area(self):
        return math.pi * (self.raio ** 2)

    def __str__(self):
        raio2casas = round(self.raio, 2) #limitar impressão para duas casas decimais
        return f"Círculo (raio, centro): {raio2casas}, {self.centro}"

'''
centro1 = Ponto2D(2.0, 3.0)
centro2 = Ponto2D(5.0, 6.0)
circulo1 = Circulo(5.0, centro1)  
circulo2 = Circulo(3.0, centro2) 

print(circulo1) 
print(circulo2)  

circulo1.inflar(2.0) 
circulo2.desinflar(1.0) 
print(f"C1 após inflar: {circulo1}")  
print(f"C2 após desinflar: {circulo2}")

novo_ponto = Ponto2D(10.0, 10.0)
circulo1.mover(novo_ponto)
print(f"C1 após mover: {circulo1}")

circulo2.mover()
print(f"Círculo 2 após mover para a origem: {circulo2}")
print(f"area C1: {circulo1.area()}")
print(f"area C2: {circulo2.area()}")
'''

centro1 = Ponto2D(2.0, 3.0)
centro2 = Ponto2D(5.0, 6.0)
circulo1 = Circulo(5.0, centro1)  
circulo2 = Circulo(3.0, centro2)

print(circulo1)
print(circulo2)

circulo1.inflar(2.0)
circulo2.desinflar(1.0)
print(f"C1 inflado: {circulo1}")
print(f"C2 desinflado: {circulo2}")

novo_ponto = Ponto2D(10.0, 10.0)
circulo1.mover(novo_ponto)
print(f"C1 após mover: {circulo1}")

circulo2.mover()
print(f"C2 após mover para a origem: {circulo2}")

print(f"Área de C1: {round(circulo1.area(), 2)}")
print(f"Área de C2: {round(circulo2.area(), 2)}")