'''
Escreva em Python uma classe Ponto2D que represente um ponto no plano 
cartesiano. A classe deve ter os parâmetros que representam abcissa e or
denada, isto é, o valor de X e Y do ponto. A classe também deve oferecer os 
seguintes membros: 
a) Construtor que permita a inicialização do ponto: 
• Por default (sem parâmetros) na origem do espaço 2D 
• Num local indicado por dois parâmetros do tipo float (indi
cando o valor de abcissa e ordenada do ponto que está sendo 
criado); 
b) Métodos de acesso (getter/setter) dos atributos do ponto 
c) Método denominado compara, que recebe um Ponto2D como parâ
metro e retorna verdadeiro caso sejam o mesmo ponto, ou falso, caso 
contrário 
d) Método de representação do objeto como string 
e) Método que permita calcular a distância do ponto do objeto, para ou
tro ponto recebido como parâmetro 
f) Método clone, que retorna uma nova instância de um ponto no 
mesmo local do objeto. 
g) Escreva código de teste que instancie objetos de exemplo e demonstre 
as capacidades da classe.
'''

import math

class Ponto2D:
    def __init__(self, x=0.0, y=0.0):
        self.x = x
        self.y = y

    def get_x(self):
        return self.x

    def set_x(self, x):
        self.x = x

    def get_y(self):
        return self.y

    def set_y(self, y):
        self.y = y

    def compara(self, outro_ponto):
        return self.x == outro_ponto.get_x() and self.y == outro_ponto.get_y()

    def __str__(self):
        return f"Ponto2D({self.x}, {self.y})"

    def calcula_distancia(self, outro_ponto):
        
        #distância euclidiana d =  √dx^2 + dy^2
        dx = self.x - outro_ponto.get_x()
        dy = self.y - outro_ponto.get_y()
        return math.sqrt(dx ** 2 + dy ** 2) #raiz quadrada

 
    def clone(self):
        return Ponto2D(self.x, self.y)

'''
if __name__ == "__main__":
    o que desejo testar aqui dentro, se o arquivo for executado 
    como python arquivo.py, mas se for importação, não vai executar
'''

p1 = Ponto2D()  #(0, 0)
p2 = Ponto2D(7.0, 2.0)
p3 = Ponto2D(7.0, 2.0)  

print(f"{p1} é igual a {p2}? {p1.compara(p2)}")
print(f"{p2} é igual a {p3}? {p2.compara(p3)}")
print(f"A distância entre o {p2} e {p3} é: {p2.calcula_distancia(p3)}") 
print(f"A distância entre o {p1} e {p2} é: {p1.calcula_distancia(p2)}") 

p4 = p2.clone()
    
print(f"Clone: {p4}") 
print(f"{p2} é igual ao clone {p4}? {p2.compara(p4)}")

